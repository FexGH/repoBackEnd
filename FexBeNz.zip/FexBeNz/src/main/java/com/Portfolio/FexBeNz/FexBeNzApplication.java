package com.Portfolio.FexBeNz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FexBeNzApplication {

	public static void main(String[] args) {
		SpringApplication.run(FexBeNzApplication.class, args);
	}

}
